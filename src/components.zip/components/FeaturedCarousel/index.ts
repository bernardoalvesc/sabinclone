export { FeaturedCarousel } from "./featuredCarousel";
export { featuredProducts } from "./featuredCarousel.mock";
